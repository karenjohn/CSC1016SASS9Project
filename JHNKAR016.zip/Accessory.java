/*KAREN JOHN
  JHNKAR016
  28/9/2023
*/


public class Accessory extends Computer {
   
    public Accessory(String serialNumber, String manufacturer, String colour) {
        super(serialNumber, manufacturer, colour);
    }
     public String toString(){
       return "Accessories: " + getSerialNumber() + ", " + getManufacturer() + ", " + getColour();
     }
}
            