/*KAREN JOHN
  JHNKAR016
  28/9/2023
*/


public class Screen extends Computer{
   private String size;
   
   public Screen(String serialNumber, String manufacturer, String colour, String size){
     super(serialNumber, manufacturer, colour);
     this.size = size;
   }
   
     public String getSize(){
       return size;
     }
     
     public String toString(){
       return "Screen: " + getSerialNumber() + ", " + getColour() + ", " + getManufacturer() + ", " + size;
     }
}
